from dnn_inference.sig_test import split_test, perm_test, Hperm_test
import sys

sys.path.append('..')

__all__ = [
    "sig_test",
	"split_test", 
	"perm_test",
	"Hperm_test"
	]
