from dnn_inference.DnnT import DnnT
from dnn_inference.PermT import PermT
