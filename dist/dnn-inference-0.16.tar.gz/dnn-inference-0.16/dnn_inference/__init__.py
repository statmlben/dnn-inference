from dnn_inference.sig_test import split_test, perm_test, Hperm_test
from dnn_inference import sig_test
from dnn_inference import base
import sys

sys.path.append('..')

# __all__ = [
#     "sig_test",
# 	"split_test", 
# 	"perm_test",
# 	"Hperm_test"
# 	]
